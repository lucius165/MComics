package vn.edu.poly.mcomics.object.handle.eventlistener;

/**
 * Created by lucius on 11/16/16.
 */

public interface DownloadEvent {
    void onLoadFinish(String string);
}
