package vn.edu.poly.mcomics.object.handle.eventlistener;

import android.view.View;

/**
 * Created by lucius on 11/16/16.
 */

public interface OnViewCreateCallback  {
    void OnViewCreate(View view, String tag);
}
