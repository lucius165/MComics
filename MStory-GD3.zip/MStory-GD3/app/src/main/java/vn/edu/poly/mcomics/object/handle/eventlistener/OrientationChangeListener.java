package vn.edu.poly.mcomics.object.handle.eventlistener;

/**
 * Created by lucius on 07/12/2016.
 */

public interface OrientationChangeListener {
    void onChanged(int orientation);
}
